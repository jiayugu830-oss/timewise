import { useApp } from '../state/AppContext';
import type { CommunityPost } from '../api/types';

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return '今天';
  if (days === 1) return '昨天';
  if (days < 30) return `${days} 天前`;
  return `${Math.floor(days / 30)} 个月前`;
}

function PostCard({ post, liked, onLike }: { post: CommunityPost; liked: boolean; onLike: () => void }) {
  return (
    <div
      style={{
        background: 'rgba(255,255,255,0.03)',
        border: '1px solid rgba(255,255,255,0.07)',
        borderRadius: 16,
        padding: '18px 18px 14px',
        marginBottom: 14,
      }}
    >
      {/* 母题标签 */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <span
          style={{
            fontSize: 10,
            letterSpacing: 1,
            padding: '3px 8px',
            borderRadius: 20,
            background: 'rgba(232,207,160,0.12)',
            color: 'rgba(232,207,160,0.8)',
          }}
        >
          {post.motifName}
        </span>
        <span style={{ fontSize: 10, color: 'rgba(214,220,228,0.3)', marginLeft: 'auto' }}>
          {post.authorLabel} · {timeAgo(post.createdAt)}
        </span>
      </div>

      {/* 原始问题大标题 */}
      <div
        style={{
          fontSize: 15,
          fontWeight: 600,
          color: '#eef1f5',
          lineHeight: 1.6,
          marginBottom: 14,
          fontFamily: "'Noto Serif SC',serif",
        }}
      >
        {post.originalQuestion}
      </div>

      {/* 回声卡片 */}
      <div
        style={{
          background: 'rgba(143,166,196,0.07)',
          border: '1px solid rgba(143,166,196,0.15)',
          borderRadius: 10,
          padding: '11px 13px',
          marginBottom: 12,
        }}
      >
        <div style={{ fontSize: 10, color: 'rgba(207,222,240,0.5)', letterSpacing: 1, marginBottom: 5 }}>
          {post.echo.figure} · {post.echo.era}
        </div>
        <div style={{ fontSize: 12.5, color: 'rgba(222,227,234,0.8)', lineHeight: 1.7, fontStyle: 'italic' }}>
          「{post.echo.one_liner}」
        </div>
      </div>

      {/* 感悟 */}
      <div
        style={{
          fontSize: 12.5,
          color: 'rgba(214,220,228,0.7)',
          lineHeight: 1.75,
          marginBottom: 14,
        }}
      >
        {post.reflection}
      </div>

      {/* 点赞 */}
      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <button
          onClick={onLike}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 5,
            background: liked ? 'rgba(232,207,160,0.12)' : 'none',
            border: `1px solid ${liked ? 'rgba(232,207,160,0.35)' : 'rgba(255,255,255,0.1)'}`,
            borderRadius: 20,
            padding: '5px 12px',
            cursor: 'pointer',
            color: liked ? 'rgba(232,207,160,0.9)' : 'rgba(214,220,228,0.45)',
            fontSize: 12,
            transition: 'all .2s',
          }}
        >
          <span style={{ fontSize: 13 }}>{liked ? '♥' : '♡'}</span>
          <span>{post.likeCount} 人也被打动</span>
        </button>
      </div>
    </div>
  );
}

export function CommunityScreen() {
  const { state, actions } = useApp();

  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column' }}>
      {/* 顶栏 */}
      <div
        style={{
          flexShrink: 0,
          paddingTop: 56,
          padding: '56px 24px 14px',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
        }}
      >
        <div style={{ fontSize: 18, fontWeight: 600, color: '#f1f3f7', letterSpacing: 3, fontFamily: "'Noto Serif SC',serif" }}>
          回声广场
        </div>
        <div style={{ fontSize: 12, color: 'rgba(214,220,228,0.45)', marginTop: 4, letterSpacing: 1 }}>
          他人的问题，也是你的问题
        </div>
      </div>

      {/* 列表 */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 18px 80px' }}>
        {state.busy && state.communityPosts.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', fontSize: 12.5, color: 'rgba(214,220,228,0.4)' }}>
            正在汇聚回声……
          </div>
        ) : state.communityPosts.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', fontSize: 12.5, color: 'rgba(214,220,228,0.4)' }}>
            还没有人分享，成为第一个吧
          </div>
        ) : (
          state.communityPosts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              liked={state.likedPostIds.includes(post.id)}
              onLike={() => void actions.toggleLike(post.id)}
            />
          ))
        )}
      </div>
    </div>
  );
}
