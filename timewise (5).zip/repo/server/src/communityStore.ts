import { randomUUID } from "node:crypto";

export interface CommunityPost {
  id: string;
  originalQuestion: string;
  motifName: string;
  echo: {
    figure: string;
    era: string;
    one_liner: string;
  };
  reflection: string;
  likeCount: number;
  likedBy: Set<string>; // client fingerprints
  authorLabel: string;
  createdAt: string;
}

export interface CommunityPostPublic {
  id: string;
  originalQuestion: string;
  motifName: string;
  echo: {
    figure: string;
    era: string;
    one_liner: string;
  };
  reflection: string;
  likeCount: number;
  authorLabel: string;
  createdAt: string;
}

const AUTHOR_LABELS = [
  "一位旅人", "路过的人", "一只信鸽", "迷路的行者",
  "寻灯者", "问渡人", "一颗浮萍", "寻北者",
];

function randomLabel() {
  return AUTHOR_LABELS[Math.floor(Math.random() * AUTHOR_LABELS.length)];
}

function toPublic(post: CommunityPost): CommunityPostPublic {
  const { likedBy: _, ...rest } = post;
  return rest;
}

// Seed data so community doesn't start empty
const seedPosts: CommunityPost[] = [
  {
    id: randomUUID(),
    originalQuestion: "我在一家公司待了五年，现在有机会去更好的地方，但我怕重新开始太晚了。",
    motifName: "去留之间",
    echo: { figure: "苏轼", era: "中国·北宋·公元1080年", one_liner: "他在最落魄时选择重新扎根，而不是停止生长。" },
    reflection: "看到苏轼在黄州种地、写赤壁赋，忽然觉得「太晚了」是我给自己设的限。他四十多岁还在重来，我还有什么理由站在原地不动？",
    likeCount: 34,
    likedBy: new Set(),
    authorLabel: "寻北者",
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
  {
    id: randomUUID(),
    originalQuestion: "父母一直希望我回老家，但我在这座城市已经有了自己的生活，不知道怎么开口说「不」。",
    motifName: "亲情与自我",
    echo: { figure: "王昭君", era: "中国·西汉·公元前33年", one_liner: "她以一人之去，换万人之安，从此再无人问她愿不愿意。" },
    reflection: "读到王昭君的那句 one_liner，我哭了。不是因为我像她——而是因为我终于明白我不是她，我可以说「不」。",
    likeCount: 61,
    likedBy: new Set(),
    authorLabel: "一位旅人",
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
  },
  {
    id: randomUUID(),
    originalQuestion: "我努力了很久，但感觉一直没有被看见，开始怀疑自己做的事情到底有没有意义。",
    motifName: "隐而不废",
    echo: { figure: "曹雪芹", era: "中国·清代·公元1750年", one_liner: "他在贫病中写完了一部没能出版的书，却成了后人最珍视的遗产。" },
    reflection: "曹雪芹大概也不知道自己的书会被几百年后的人读到。也许「被看见」不是我该在意的事，而是继续写下去。",
    likeCount: 28,
    likedBy: new Set(),
    authorLabel: "一只信鸽",
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
];

const posts: CommunityPost[] = [...seedPosts];

export function getPosts(): CommunityPostPublic[] {
  return [...posts]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .map(toPublic);
}

export function createPost(data: {
  originalQuestion: string;
  motifName: string;
  echo: { figure: string; era: string; one_liner: string };
  reflection: string;
}): CommunityPostPublic {
  const post: CommunityPost = {
    id: randomUUID(),
    ...data,
    likeCount: 0,
    likedBy: new Set(),
    authorLabel: randomLabel(),
    createdAt: new Date().toISOString(),
  };
  posts.unshift(post);
  return toPublic(post);
}

export function toggleLike(postId: string, fingerprint: string): { likeCount: number; liked: boolean } | null {
  const post = posts.find((p) => p.id === postId);
  if (!post) return null;
  if (post.likedBy.has(fingerprint)) {
    post.likedBy.delete(fingerprint);
    post.likeCount = Math.max(0, post.likeCount - 1);
    return { likeCount: post.likeCount, liked: false };
  } else {
    post.likedBy.add(fingerprint);
    post.likeCount += 1;
    return { likeCount: post.likeCount, liked: true };
  }
}
