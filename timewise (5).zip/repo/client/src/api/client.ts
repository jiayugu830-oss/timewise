import type {
  ClarifyTurn,
  ConversationTurn,
  Essence,
  Motif,
  EchoItem,
  EchoSearchResponse,
  EchoRefreshResponse,
  EchoDetail,
  AuthUser,
  CommunityPost,
} from './types';

// Backend base URL. In production set VITE_API_BASE to the deployed backend
// origin (e.g. https://timewise-server.onrender.com). Left empty in local dev
// so requests hit the Vite proxy (see vite.config.ts).
const API_BASE = (import.meta.env.VITE_API_BASE ?? '').replace(/\/$/, '');

export function apiUrl(path: string): string {
  return `${API_BASE}${path}`;
}

async function postJSON<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(apiUrl(path), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    throw new Error(`Request to ${path} failed (${res.status})`);
  }
  return res.json() as Promise<T>;
}

export function fetchClarifyTurn(userQuestion: string, history: ConversationTurn[]) {
  return postJSON<ClarifyTurn>('/api/clarify', {
    user_question: userQuestion,
    conversation_history: history,
  });
}

export function fetchEssence(userQuestion: string, history: ConversationTurn[]) {
  return postJSON<Essence>('/api/essence', {
    user_question: userQuestion,
    conversation_history: history,
  });
}

export function fetchMotif(essentialQuestion: string, history: ConversationTurn[]) {
  return postJSON<Motif>('/api/motif', {
    essential_question: essentialQuestion,
    conversation_history: history,
  });
}

export function searchEchoes(userQuestion: string, essentialQuestion: string, motifName: string) {
  return postJSON<EchoSearchResponse>('/api/echoes/search', {
    user_question: userQuestion,
    essential_question: essentialQuestion,
    motif_name: motifName,
  });
}

export function refreshEchoes(sessionId: string) {
  return postJSON<EchoRefreshResponse>('/api/echoes/refresh', { session_id: sessionId });
}

export function fetchEchoDetail(userQuestion: string, essentialQuestion: string, selectedEcho: EchoItem) {
  return postJSON<EchoDetail>('/api/echo-detail', {
    user_question: userQuestion,
    essential_question: essentialQuestion,
    selected_echo: selectedEcho,
  });
}

export function authRegister(email: string, password: string) {
  return postJSON<{ user: AuthUser; token: string }>('/api/auth/register', { email, password });
}

export function authLogin(email: string, password: string) {
  return postJSON<{ user: AuthUser; token: string }>('/api/auth/login', { email, password });
}

export function fetchCommunityPosts(): Promise<CommunityPost[]> {
  return fetch(apiUrl('/api/community/posts')).then((r) => r.json() as Promise<CommunityPost[]>);
}

export function createCommunityPost(data: {
  originalQuestion: string;
  motifName: string;
  echo: { figure: string; era: string; one_liner: string };
  reflection: string;
}): Promise<CommunityPost> {
  return postJSON<CommunityPost>('/api/community/posts', data);
}

export function toggleCommunityLike(postId: string, fingerprint: string): Promise<{ likeCount: number; liked: boolean }> {
  return postJSON('/api/community/posts/' + postId + '/like', { fingerprint });
}
