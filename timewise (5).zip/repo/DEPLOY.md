# 部署指南（在线跑通版）

架构：**前端 → Vercel**，**后端 → Render**。两者分开部署，前端通过环境变量指向后端。

---

## 第一步：部署后端到 Render

1. 打开 https://render.com ，用 GitHub 登录。
2. **New → Blueprint**，选择本仓库。Render 会自动读取根目录的 `render.yaml`。
3. 部署时它会要求填 `ARK_API_KEY` —— 填入你自己的火山方舟 API Key。
4. 部署完成后，复制服务地址，形如：
   `https://timewise-server.onrender.com`

> 注意：Render 免费套餐的服务闲置后会休眠，第一次请求可能要等 30~60 秒唤醒，属正常现象。

---

## 第二步：部署前端到 Vercel

1. 打开 https://vercel.com ，导入本仓库。
2. **Root Directory 必须设为 `client`**（这是页面显示乱掉的根本原因）。
   框架会自动识别为 Vite，Build Command `npm run build`，Output `dist`。
3. 在 **Settings → Environment Variables** 添加：
   - Name: `VITE_API_BASE`
   - Value: 第一步拿到的 Render 后端地址（如 `https://timewise-server.onrender.com`）
4. 重新 Deploy。

---

## 第三步：验证

打开 Vercel 给的网址 → 开始提问 → 如果能走完澄清对话并抽出历史回声，说明前后端已打通。

---

## 本地开发（不受影响）

本地不需要设 `VITE_API_BASE`，前端会走 `vite.config.ts` 里的 proxy 转发到 `localhost:8787`：

```bash
cd server && npm install && npm run dev     # 终端 1
cd client && npm install && npm run dev     # 终端 2
```
