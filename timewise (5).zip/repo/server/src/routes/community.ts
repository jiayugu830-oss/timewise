import { Router } from "express";
import { z } from "zod";
import { getPosts, createPost, toggleLike } from "../communityStore.js";

export const communityRouter = Router();

communityRouter.get("/posts", (_req, res) => {
  res.json(getPosts());
});

const CreatePostSchema = z.object({
  originalQuestion: z.string().min(1).max(200),
  motifName: z.string().min(1).max(20),
  echo: z.object({
    figure: z.string().min(1),
    era: z.string().min(1),
    one_liner: z.string().min(1),
  }),
  reflection: z.string().min(1).max(500),
});

communityRouter.post("/posts", (req, res) => {
  const parsed = CreatePostSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "invalid_request", details: parsed.error.flatten() });
  }
  const post = createPost(parsed.data);
  res.status(201).json(post);
});

communityRouter.post("/posts/:id/like", (req, res) => {
  const { id } = req.params;
  const fingerprint = (req.body as { fingerprint?: string }).fingerprint ?? "anon";
  const result = toggleLike(id, fingerprint);
  if (!result) return res.status(404).json({ error: "not_found" });
  res.json(result);
});
