import { useApp } from '../state/AppContext';

export function ComposeScreen() {
  const { state, actions } = useApp();
  const echo = state.activeEcho;

  if (!echo) return null;

  const canSubmit = state.composeReflection.trim().length > 0 && !state.busy;

  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column' }}>
      {/* 顶栏 */}
      <div
        style={{
          flexShrink: 0,
          paddingTop: 56,
          padding: '56px 20px 14px',
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          borderBottom: '1px solid rgba(255,255,255,0.06)',
        }}
      >
        <button
          onClick={actions.backFromDetail}
          style={{ background: 'none', border: 'none', color: 'rgba(214,220,228,0.7)', fontSize: 20, cursor: 'pointer', padding: 4 }}
        >
          ‹
        </button>
        <div style={{ flex: 1, fontSize: 15, fontWeight: 600, color: '#eef1f5', letterSpacing: 2, fontFamily: "'Noto Serif SC',serif" }}>
          分享到回声广场
        </div>
        <button
          onClick={() => void actions.submitPost()}
          disabled={!canSubmit}
          style={{
            padding: '7px 16px',
            borderRadius: 20,
            border: 'none',
            background: canSubmit ? 'linear-gradient(180deg,#e9edf3,#c9d4e2)' : 'rgba(255,255,255,0.08)',
            color: canSubmit ? '#13202e' : 'rgba(214,220,228,0.3)',
            fontFamily: "'Noto Serif SC',serif",
            fontSize: 13,
            fontWeight: 600,
            cursor: canSubmit ? 'pointer' : 'default',
            letterSpacing: 1,
          }}
        >
          {state.busy ? '发布中…' : '发 布'}
        </button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '20px 20px 40px' }}>
        {/* 你的问题（只读展示） */}
        <div style={{ fontSize: 11, color: 'rgba(232,207,160,0.7)', letterSpacing: 1, marginBottom: 8 }}>你的问题</div>
        <div
          style={{
            fontSize: 14,
            fontWeight: 600,
            color: '#eef1f5',
            lineHeight: 1.65,
            fontFamily: "'Noto Serif SC',serif",
            marginBottom: 20,
            padding: '12px 14px',
            background: 'rgba(255,255,255,0.03)',
            borderRadius: 10,
            border: '1px solid rgba(255,255,255,0.07)',
          }}
        >
          {state.userQuestion}
        </div>

        {/* 选择的回声（只读） */}
        <div style={{ fontSize: 11, color: 'rgba(232,207,160,0.7)', letterSpacing: 1, marginBottom: 8 }}>你选择的历史回声</div>
        <div
          style={{
            background: 'rgba(143,166,196,0.07)',
            border: '1px solid rgba(143,166,196,0.15)',
            borderRadius: 12,
            padding: '14px 15px',
            marginBottom: 24,
          }}
        >
          <div style={{ fontSize: 10.5, color: 'rgba(207,222,240,0.5)', letterSpacing: 1, marginBottom: 6 }}>
            {echo.figure} · {echo.era}
          </div>
          <div style={{ fontSize: 13, color: 'rgba(222,227,234,0.85)', lineHeight: 1.7, fontStyle: 'italic' }}>
            「{echo.one_liner}」
          </div>
        </div>

        {/* 感悟输入 */}
        <div style={{ fontSize: 11, color: 'rgba(232,207,160,0.7)', letterSpacing: 1, marginBottom: 8 }}>
          你的感悟
          <span style={{ color: 'rgba(214,220,228,0.3)', marginLeft: 8, fontWeight: 400 }}>
            （{state.composeReflection.length}/500）
          </span>
        </div>
        <textarea
          value={state.composeReflection}
          onChange={(e) => actions.onComposeChange(e.target.value)}
          maxLength={500}
          placeholder="这段历史让你想到了什么……"
          style={{
            width: '100%',
            minHeight: 140,
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: 12,
            padding: '14px 14px',
            fontSize: 13.5,
            color: '#dde4ee',
            lineHeight: 1.75,
            resize: 'none',
            outline: 'none',
            fontFamily: "'Noto Serif SC',serif",
            boxSizing: 'border-box',
          }}
        />

        <div
          style={{
            marginTop: 20,
            padding: '12px 14px',
            background: 'rgba(143,166,196,0.05)',
            borderRadius: 10,
            fontSize: 11.5,
            color: 'rgba(214,220,228,0.4)',
            lineHeight: 1.7,
          }}
        >
          发布后，你的原始问题和感悟会以匿名方式出现在回声广场，不展示任何个人信息。
        </div>
      </div>
    </div>
  );
}
